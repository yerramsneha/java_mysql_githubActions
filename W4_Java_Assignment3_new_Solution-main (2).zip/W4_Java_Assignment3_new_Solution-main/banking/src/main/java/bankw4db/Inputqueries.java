package bankw4db;

public class Inputqueries 
{
   public String problem1()
   {
	   String p1 = "select * from branch";
	   return p1;
   }
   
}
